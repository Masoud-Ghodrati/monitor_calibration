/*
 *	X-Rite I1 MATLAB library
 *	Created by Peter April.
 *	Copyright (C) 2012 Peter April, VPixx Technologies
 *	
 *	This library is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU Library General Public
 *	License as published by the Free Software Foundation; either
 *	version 2 of the License, or (at your option) any later version.
 *	
 *	This library is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *	Library General Public License for more details.
 *	
 *	You should have received a copy of the GNU Library General Public
 *	License along with this library; if not, write to the
 *	Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
 *	Boston, MA  02110-1301, USA.
 *
 */

/*
	PsychI1.h
  
	PROJECT: I1  

	AUTHORS:

		papril@vpixx.com	paa 

	PLATFORMS:  OS X, Windows XP


	HISTORY:

		8/21/12		paa		Created. 

*/

#ifndef PSYCH_IS_INCLUDED_I1
#define PSYCH_IS_INCLUDED_I1

#include "Psych.h"

// Functions registered with the Psychtoolbox library 
PsychError	PsychDisplayI1Synopsis(void);

// Setup functions
PsychError	PtbI1IsConnected(void);						// Returns non-0 if an X-Rite i1 has been detected
PsychError	PtbI1Calibrate(void);						// Call once after i1 powerup, before TriggerMeasurement, with i1 on white calibration tile
PsychError	PtbI1KeyPressed(void);						// Returns non-0 if i1 button has been pressed
PsychError	PtbI1TriggerMeasurement(void);				// Initiates a measurement using i1
PsychError	PtbI1GetTriStimulus(void);					// Returns CIE Lxy coordinates of last i1 measurement
PsychError	PtbI1GetSpectrum(void);						// Returns raw spectral power data for last i1 measurement

#endif
