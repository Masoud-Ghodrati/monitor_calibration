/*
 *	X-Rite I1 MATLAB library
 *	Created by Peter April.
 *	Copyright (C) 2012 Peter April, VPixx Technologies
 *	
 *	This library is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU Library General Public
 *	License as published by the Free Software Foundation; either
 *	version 2 of the License, or (at your option) any later version.
 *	
 *	This library is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *	Library General Public License for more details.
 *	
 *	You should have received a copy of the GNU Library General Public
 *	License along with this library; if not, write to the
 *	Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
 *	Boston, MA  02110-1301, USA.
 *
 */

/*
    PsychI1.c

    PROJECT: I1

    AUTHORS:

        papril@vpixx.com     paa 

    PLATFORMS:    OS X, Windows XP


    HISTORY:

		8/21/12		paa		Created. 

*/

#include "PsychI1.h"
#include "EyeOne.h"

/*
 * CODING NOTES:
 *
 *  -PsychErrorExitMsg strings should not terminate in \n, since the macro expansion adds one.
 *  -Use mexPrintf for printing my own strings, and terminate with \n.
 */


#define MAX_SYNOPSIS_STRINGS 100  

//declare variables local to this file.  
static const char *synopsisSYNOPSIS[MAX_SYNOPSIS_STRINGS];

void InitializeSynopsis()
{
    int i=0;
    const char **synopsis = synopsisSYNOPSIS;

    synopsis[i++] = "Usage:";

    synopsis[i++] = "\n% I1 functions:";
    synopsis[i++] = "isConnected = I1('IsConnected');";
    synopsis[i++] = "I1('Calibrate');";
    synopsis[i++] = "keyPressed = I1('KeyPressed');";
    synopsis[i++] = "I1('TriggerMeasurement');";
    synopsis[i++] = "Lxy = I1('GetTriStimulus');";
    synopsis[i++] = "spectrum = I1('GetSpectrum');";

    synopsis[i++] = NULL;   // This tells PsychDisplayScreenSynopsis where to stop

    if (i > MAX_SYNOPSIS_STRINGS)
        PrintfExit("%s: increase dimension of synopsis[] from %ld to at least %ld and recompile.",__FILE__,(long)MAX_SYNOPSIS_STRINGS,(long)i);
}


PsychError PsychDisplayI1Synopsis(void)
{
    int i;

    for (i = 0; synopsisSYNOPSIS[i] != NULL; i++)
        mexPrintf("%s\n", synopsisSYNOPSIS[i]);

    return(PsychError_none);
}


// Returns non-0 if an X-Rite I1 has been detected
PsychError PtbI1IsConnected(void)
{
    static char useString[] = "isConnected = I1('IsConnected');";
    static char synopsisString[] = "Returns non-0 if an X-Rite I1 has been detected.\n";
    static char seeAlsoString[] = "Calibrate, KeyPressed, TriggerMeasurement, GetTriStimulus, GetSpectrum";

    int isConnected;

    // Help support
    PsychPushHelp(useString, synopsisString, seeAlsoString);
    if (PsychIsGiveHelp()) { PsychGiveHelp(); return(PsychError_none); };

    // Qualify number of I/O args
    PsychErrorExit(PsychRequireNumInputArgs(0));
    PsychErrorExit(PsychCapNumInputArgs(0));
    PsychErrorExit(PsychCapNumOutputArgs(1));

    // Do we recognize an X-Rite i1-Pro USB connection?
    if (I1_IsConnected() == eNoError) {
        if(strncmp(I1_GetOption(I1_DEVICE_TYPE), I1_EYEONE, 6) == 0)
            isConnected = 1;
        else
            PsychErrorExitMsg(PsychError_user, "ERROR: Unrecognized i1 device.");
    }
    else
        isConnected = 0;

    PsychCopyOutFlagArg(1, kPsychArgOptional, isConnected);

    return(PsychError_none);    
}


// Call once after i1 powerup, before TriggerMeasurement, with i1 on white calibration tile
PsychError PtbI1Calibrate(void)
{
    static char useString[] = "I1('Calibrate');";
    static char synopsisString[] = "Call once after i1 powerup, before TriggerMeasurement, with i1 on white calibration tile.\n";
    static char seeAlsoString[] = "IsConnected, KeyPressed, TriggerMeasurement, GetTriStimulus, GetSpectrum";

    char errMsg[256];
    
    // Help support
    PsychPushHelp(useString, synopsisString, seeAlsoString);
    if (PsychIsGiveHelp()) { PsychGiveHelp(); return(PsychError_none); };
    
    // Qualify number of I/O args
    PsychErrorExit(PsychRequireNumInputArgs(0));
    PsychErrorExit(PsychCapNumInputArgs(0));
    PsychErrorExit(PsychCapNumOutputArgs(0));

    if (I1_IsConnected() != eNoError)
        PsychErrorExitMsg(PsychError_user, "ERROR: No i1 detected in system.");

    I1_SetOption(I1_MEASUREMENT_MODE, I1_SINGLE_EMISSION);
    I1_SetOption(ILLUMINATION_KEY, ILLUMINATION_EMISSION);
    I1_SetOption(COLOR_SPACE_KEY, COLOR_SPACE_CIExyY);

    if (I1_Calibrate() != eNoError) {
        sprintf(errMsg, "ERROR: Calibration failed with error: %s.", I1_GetOption(I1_LAST_ERROR));
        PsychErrorExitMsg(PsychError_user, errMsg);
    }

    return(PsychError_none);    
}


// Returns non-0 if i1 button has been pressed
PsychError PtbI1KeyPressed(void)
{
    static char useString[] = "keyPressed = I1('KeyPressed');";
    static char synopsisString[] = "Returns non-0 if i1 button has been pressed.\n"
                                   "Note that the i1 internally buffers one button press.\n";
    static char seeAlsoString[] = "IsConnected, Calibrate, TriggerMeasurement, GetTriStimulus, GetSpectrum";
    
    int keyPressed;
    
    // Help support
    PsychPushHelp(useString, synopsisString, seeAlsoString);
    if (PsychIsGiveHelp()) { PsychGiveHelp(); return(PsychError_none); };
    
    // Qualify number of I/O args
    PsychErrorExit(PsychRequireNumInputArgs(0));
    PsychErrorExit(PsychCapNumInputArgs(0));
    PsychErrorExit(PsychCapNumOutputArgs(1));

    if (I1_IsConnected() != eNoError)
        PsychErrorExitMsg(PsychError_user, "ERROR: No i1 detected in system.");
    
    keyPressed = I1_KeyPressed() == eNoError ? 1 : 0;
    PsychCopyOutFlagArg(1, kPsychArgOptional, keyPressed);
    
    return(PsychError_none);    
}


// Initiates a measurement using i1
PsychError PtbI1TriggerMeasurement(void)
{
    static char useString[] = "I1('TriggerMeasurement');";
    static char synopsisString[] = "Initiates a measurement using i1.\n"
                                   "Upon return, measurement data can be read using GetTriStimulus or GetSpectrum.\n";
    static char seeAlsoString[] = "IsConnected, Calibrate, KeyPressed, GetTriStimulus, GetSpectrum";

    I1_ErrorType i1Error;

    // Help support
    PsychPushHelp(useString, synopsisString, seeAlsoString);
    if (PsychIsGiveHelp()) { PsychGiveHelp(); return(PsychError_none); };
    
    // Qualify number of I/O args
    PsychErrorExit(PsychRequireNumInputArgs(0));
    PsychErrorExit(PsychCapNumInputArgs(0));
    PsychErrorExit(PsychCapNumOutputArgs(0));
    
    if (I1_IsConnected() != eNoError)
        PsychErrorExitMsg(PsychError_user, "ERROR: No i1 detected in system.");
    I1_SetOption(I1_MEASUREMENT_MODE, I1_SINGLE_EMISSION);
    I1_SetOption(ILLUMINATION_KEY, ILLUMINATION_EMISSION);
    I1_SetOption(COLOR_SPACE_KEY, COLOR_SPACE_CIExyY);

    i1Error = I1_TriggerMeasurement();

    if (i1Error == eDeviceNotConnected)
        PsychErrorExitMsg(PsychError_user, "ERROR: No i1 detected in system.");
    if (i1Error == eDeviceNotCalibrated)
        PsychErrorExitMsg(PsychError_user, "ERROR: i1 hasn't been calibrated. See I1('Calibrate').");
    if (i1Error != eNoError)
        PsychErrorExitMsg(PsychError_user, "ERROR: Unknown i1 error.");
        
    return(PsychError_none);    
}


// Returns CIE Lxy coordinates of last i1 measurement
PsychError PtbI1GetTriStimulus(void)
{
    static char useString[] = "Lxy = I1('GetTriStimulus');";
    static char synopsisString[] = "Returns CIE Lxy coordinates of last i1 measurement.\n";
    static char seeAlsoString[] = "IsConnected, Calibrate, KeyPressed, TriggerMeasurement, GetSpectrum";

    I1_ErrorType i1Error;
    float alTristimulus[TRISTIMULUS_SIZE];
    double *returnDataPtr;

    // Help support
    PsychPushHelp(useString, synopsisString, seeAlsoString);
    if (PsychIsGiveHelp()) { PsychGiveHelp(); return(PsychError_none); };
    
    // Qualify number of I/O args
    PsychErrorExit(PsychRequireNumInputArgs(0));
    PsychErrorExit(PsychCapNumInputArgs(0));
    PsychErrorExit(PsychCapNumOutputArgs(1));

    i1Error = I1_GetTriStimulus(alTristimulus, 0);
    
    if (i1Error == eNoDataAvailable)
        PsychErrorExitMsg(PsychError_user, "ERROR: No i1 data available. See I1('TriggerMeasurement').");
    if (i1Error != eNoError)
        PsychErrorExitMsg(PsychError_user, "ERROR: Unknown i1 error.");

    PsychAllocOutDoubleMatArg(1, kPsychArgOptional, 1, 3, 1, &returnDataPtr);
    returnDataPtr[0] = alTristimulus[2];    // L
    returnDataPtr[1] = alTristimulus[0];    // x
    returnDataPtr[2] = alTristimulus[1];    // y
    
    return(PsychError_none);    
}


// Returns raw spectral power data for last i1 measurement
PsychError PtbI1GetSpectrum(void)
{
    static char useString[] = "spectrum = I1('GetSpectrum');";
    static char synopsisString[] = "Returns raw spectral power data for last i1 measurement.\n"
                                   "Data are in 10nm increments from 380nm to 730nm.\n";
    static char seeAlsoString[] = "IsConnected, Calibrate, KeyPressed, TriggerMeasurement, GetTriStimulus";
    
    I1_ErrorType i1Error;
    float spectralData[SPECTRUM_SIZE];
    double *returnDataPtr;
    int iDatum;
    
    // Help support
    PsychPushHelp(useString, synopsisString, seeAlsoString);
    if (PsychIsGiveHelp()) { PsychGiveHelp(); return(PsychError_none); };
    
    // Qualify number of I/O args
    PsychErrorExit(PsychRequireNumInputArgs(0));
    PsychErrorExit(PsychCapNumInputArgs(0));
    PsychErrorExit(PsychCapNumOutputArgs(1));
    
    i1Error = I1_GetSpectrum(spectralData, 0);
    
    if (i1Error == eNoDataAvailable)
        PsychErrorExitMsg(PsychError_user, "ERROR: No i1 data available. See I1('TriggerMeasurement').");
    if (i1Error != eNoError)
        PsychErrorExitMsg(PsychError_user, "ERROR: Unknown i1 error.");
    
    PsychAllocOutDoubleMatArg(1, kPsychArgOptional, 1, SPECTRUM_SIZE, 1, &returnDataPtr);
    for (iDatum = 0; iDatum < SPECTRUM_SIZE; iDatum++)
        *returnDataPtr++ = spectralData[iDatum];
    
    return(PsychError_none);    
}
