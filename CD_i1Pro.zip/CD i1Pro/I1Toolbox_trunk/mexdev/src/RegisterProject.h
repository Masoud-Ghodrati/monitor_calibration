/*
 *	X-Rite I1 MATLAB library
 *	Created by Peter April.
 *	Copyright (C) 2012 Peter April, VPixx Technologies
 *	
 *	This library is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU Library General Public
 *	License as published by the Free Software Foundation; either
 *	version 2 of the License, or (at your option) any later version.
 *	
 *	This library is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *	Library General Public License for more details.
 *	
 *	You should have received a copy of the GNU Library General Public
 *	License along with this library; if not, write to the
 *	Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
 *	Boston, MA  02110-1301, USA.
 *
 */

/*
	RegisterProject.h		

	PROJECT: I1  

	AUTHORS:

		papril@vpixx.com	 paa 

	PLATFORMS:  OS X, Windows XP


	HISTORY:

		8/21/12		paa		Created. 

*/

#ifndef PSYCH_IS_INCLUDED_RegisterProject
#define PSYCH_IS_INCLUDED_RegisterProject

#include "Psych.h"
#include "PsychI1.h"

// Functions referenced by PTB, and defined in RegisterProject.c
PsychError PsychModuleInit(void);

// PTB functions which we reference in RegisterProject.c, but which have no decl elsewhere
PsychError MODULEVersion(void);

// Local functions defined and used in RegisterProject.c
void InitializeSynopsis(void);

#endif




