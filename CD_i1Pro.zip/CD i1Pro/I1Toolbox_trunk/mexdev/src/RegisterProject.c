/*
 *	X-Rite I1 MATLAB library
 *	Created by Peter April.
 *	Copyright (C) 2012 Peter April, VPixx Technologies
 *	
 *	This library is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU Library General Public
 *	License as published by the Free Software Foundation; either
 *	version 2 of the License, or (at your option) any later version.
 *	
 *	This library is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *	Library General Public License for more details.
 *	
 *	You should have received a copy of the GNU Library General Public
 *	License along with this library; if not, write to the
 *	Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
 *	Boston, MA  02110-1301, USA.
 *
 */

/*
	RegisterProject.h		

	PROJECT: I1  

	AUTHORS:

		papril@vpixx.com	paa 

	PLATFORMS:  OS X, Windows XP


	HISTORY:

		8/21/12		paa		Created. 

*/

#include "RegisterProject.h"


// A little shorthand for quick calls to PsychRegister
#define FUNDEF(name) PsychErrorExit(PsychRegister(#name,  &PtbI1##name));


PsychError PsychModuleInit(void)
{
	PsychSetModuleAuthorByInitials("paa");

    // This causes PtbDPxExitFunction to be executed whenever this module gets purged.
    // The idea is to do any necessary cleanup which maybe the user didn't do;
// 	PsychErrorExitMsg(PsychRegisterExit(&PtbI1ExitFunction), "Failed to register the I1 exit function.");

	// Register the project function which is called when the module is invoked with no arguments:
	InitializeSynopsis();
	PsychErrorExitMsg(PsychRegister(NULL,  &PsychDisplayI1Synopsis), "Failed to register the I1 synopsis function.");

	// Register the module name
	 PsychErrorExitMsg(PsychRegister("I1", NULL), "Failed to register the I1 module name.");

	// PTB implements version reporting
	PsychErrorExit(PsychRegister("Version",  &MODULEVersion));

	// I1 functions
	FUNDEF(IsConnected);
	FUNDEF(Calibrate);
	FUNDEF(KeyPressed);
	FUNDEF(TriggerMeasurement);
	FUNDEF(GetTriStimulus);
	FUNDEF(GetSpectrum);

	return(PsychError_none);
}
