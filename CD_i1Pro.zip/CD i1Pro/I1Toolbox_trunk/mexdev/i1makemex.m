function i1makemex()

    if (IsOSX | strcmp(computer,'MACI64'))
        VPIXXDIR = '/Users/papril/Documents/VPixx/';
        CPYCMD = 'cp ';
        DELCMD = 'rm ';
    elseif (IsWin)
        VPIXXDIR = 'V:/';
        CPYCMD = 'copy ';
        DELCMD = 'del ';
    end

    PTBDIR = [VPIXXDIR 'svn_Psychtoolbox/'];

    % Windows/Matlab combination doesn't recognize .cc extension.
    % No problem.  Seems all combinations can compile PsychScriptingGlue.cc as a straight C file,
    % so just copy to a file with the standard C extension.
    % NOTE: Don't just rename the file, or it will fail on the second pass.
    S = [CPYCMD PTBDIR 'PsychSourceGL/Source/Common/Base/PsychScriptingGlue.cc ' PTBDIR 'PsychSourceGL/Source/Common/Base/PsychScriptingGlue.c'];
    system(strrep(S, '/', filesep));

    S = 'mex -v';   % -v for verbose output

    if (IsOctave)
        S = [S ' -DPTBOCTAVE3MEX'];
    end

    S = [S ' -I' VPIXXDIR 'svn_Software/I1Toolbox_trunk/mexdev/src'];
    S = [S ' -I' PTBDIR 'PsychSourceGL/Source/Common/Base'];
    S = [S ' -I' PTBDIR 'PsychSourceGL/Source/Common/Screen'];

    if (IsOSX | strcmp(computer,'MACI64'))
        S = [S ' -I' VPIXXDIR 'svn_ThirdParty/EyeOne/OSX_EyeOne_SDK_3.4.2/SDK'];
        S = [S ' -I' PTBDIR 'PsychSourceGL/Source/OSX/Base'];
        S = [S ' -I' PTBDIR 'PsychSourceGL/Source/OSX/Screen'];
        S = [S ' -I' PTBDIR 'PsychSourceGL/Source/OSX/Fonts'];
    elseif (IsWin)
        S = [S ' -I' VPIXXDIR 'svn_ThirdParty/EyeOne/WINXP_EyeOne_SDK_3/include'];
        S = [S ' -I' PTBDIR 'PsychSourceGL/Source/Windows/Base'];
        S = [S ' -I' PTBDIR 'PsychSourceGL/Source/Windows/Screen'];
        S = [S ' -I"C:/Program Files/QuickTime SDK/CIncludes"'];    % For Movies.h
        S = [S ' -DWIN_BUILD'];    % libdpx DPxOpen mod under Windows
    end

    S = [S ' ' VPIXXDIR 'svn_Software/I1Toolbox_trunk/mexdev/src/PsychI1.c'];
    S = [S ' ' VPIXXDIR 'svn_Software/I1Toolbox_trunk/mexdev/src/RegisterProject.c'];
    S = [S ' ' PTBDIR 'PsychSourceGL/Source/Common/Base/MiniBox.c'];
    S = [S ' ' PTBDIR 'PsychSourceGL/Source/Common/Base/ProjectTable.c'];
    S = [S ' ' PTBDIR 'PsychSourceGL/Source/Common/Base/PsychAuthors.c'];
    S = [S ' ' PTBDIR 'PsychSourceGL/Source/Common/Base/PsychCellGlue.c'];
    S = [S ' ' PTBDIR 'PsychSourceGL/Source/Common/Base/PsychError.c'];
    S = [S ' ' PTBDIR 'PsychSourceGL/Source/Common/Base/PsychHelp.c'];
    S = [S ' ' PTBDIR 'PsychSourceGL/Source/Common/Base/PsychInit.c'];
    S = [S ' ' PTBDIR 'PsychSourceGL/Source/Common/Base/PsychInstrument.c'];
    S = [S ' ' PTBDIR 'PsychSourceGL/Source/Common/Base/PsychMemory.c'];
    S = [S ' ' PTBDIR 'PsychSourceGL/Source/Common/Base/PsychRegisterProject.c'];
    S = [S ' ' PTBDIR 'PsychSourceGL/Source/Common/Base/PsychStructGlue.c'];
    S = [S ' ' PTBDIR 'PsychSourceGL/Source/Common/Base/PsychVersioning.c'];
    S = [S ' ' PTBDIR 'PsychSourceGL/Source/Common/Base/PsychScriptingGlue.c'];
    S = [S ' ' PTBDIR 'PsychSourceGL/Source/Common/Base/MODULEVersion.c'];

    if (IsOSX | strcmp(computer,'MACI64'))
        S = [S ' ' PTBDIR 'PsychSourceGL/Source/OSX/Base/PsychTimeGlue.c'];
        if (IsOctave)
            S = [S ' --output ' VPIXXDIR 'svn_Software/I1Toolbox_trunk/mexdev/build/octave/macosx/I1.mex'];
        else
            if (strcmp(computer,'MACI64'))
                S = [S ' -output ' VPIXXDIR 'svn_Software/I1Toolbox_trunk/mexdev/build/matlab/macosx64/I1'];
            else
                S = [S ' -output ' VPIXXDIR 'svn_Software/I1Toolbox_trunk/mexdev/build/matlab/macosx/I1'];
            end
        end
    elseif (IsWin)
        S = [S ' ' PTBDIR 'PsychSourceGL/Source/Windows/Base/PsychTimeGlue.c'];
        S = [S ' -L' VPIXXDIR 'svn_ThirdParty/EyeOne/WINXP_EyeOne_SDK_3/lib -lEyeOne'];
        if (IsOctave)
            S = [S ' -lWinmm']; % for timeGetTime() et al
            S = [S ' --output ' VPIXXDIR 'svn_Software/I1Toolbox_trunk/mexdev/build/octave/win32/I1.mex'];
        else
            S = [S ' -L"C:/Program Files/Microsoft Visual Studio/VC98/Lib" -lWinmm']; % for timeGetTime() et al
            S = [S ' -output ' VPIXXDIR 'svn_Software/I1Toolbox_trunk/mexdev/build/matlab/win32/I1.mexw32'];
        end
    end

    eval(strrep(S, '/', filesep));

%   Move mex file to final destination, and clean up any temporary build files.
%   Octave puts object files in same folders as source files, and we have to delete them manually.
%   Matlab is a bit smarter, putting the object files in the current directory, then immediately cleaning them up.
    if (IsOctave)
        system(strrep([DELCMD VPIXXDIR 'svn_Software/I1Toolbox_trunk/mexdev/src/*.o'], '/', filesep));
        system(strrep([DELCMD PTBDIR 'PsychSourceGL/Source/Common/Base/*.o'], '/', filesep));
        % system(strrep([DELCMD PTBDIR 'PsychSourceGL/Source/Common/Screen/*.o'], '/', filesep));
        if (IsOSX)
            system(strrep([DELCMD PTBDIR 'PsychSourceGL/Source/OSX/Base/*.o'], '/', filesep));
            system(strrep([CPYCMD VPIXXDIR 'svn_Software/I1Toolbox_trunk/mexdev/build/octave/macosx/I1.mex ' PTBDIR 'Psychtoolbox/PsychBasic/Octave3OSXFiles'], '/', filesep));
        elseif (IsWin)
            system(strrep([DELCMD PTBDIR 'PsychSourceGL/Source/Windows/Base/*.o'], '/', filesep));
            system(strrep([CPYCMD VPIXXDIR 'svn_Software/I1Toolbox_trunk/mexdev/build/octave/win32/I1.mex ' PTBDIR 'Psychtoolbox/PsychBasic/Octave3WindowsFiles'], '/', filesep));
        end
    else
        if (strcmp(computer,'MACI64'))
            system(strrep([CPYCMD VPIXXDIR 'svn_Software/I1Toolbox_trunk/mexdev/build/matlab/macosx64/I1.' mexext ' ' PTBDIR 'Psychtoolbox/PsychBasic'], '/', filesep));
        elseif (IsOSX)
            system(strrep([CPYCMD VPIXXDIR 'svn_Software/I1Toolbox_trunk/mexdev/build/matlab/macosx/I1.' mexext ' ' PTBDIR 'Psychtoolbox/PsychBasic'], '/', filesep));
        elseif (IsWin)
            system(strrep([CPYCMD VPIXXDIR 'svn_Software/I1Toolbox_trunk/mexdev/build/matlab/win32/I1.mexw32 ' PTBDIR 'Psychtoolbox/PsychBasic/MatlabWindowsFilesR2007a'], '/', filesep));
        end
    end

return;
